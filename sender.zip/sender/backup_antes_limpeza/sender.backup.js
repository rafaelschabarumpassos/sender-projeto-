const fs = require('fs');
const path = require('path');
const axios = require('axios');

// ====================== UTILS ======================
function loadJson(name) {
    const file = path.join(__dirname, name);
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function saveJson(name, data) {
    const file = path.join(__dirname, name);
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function wait(ms) {
    return new Promise(r => setTimeout(r, ms));
}

// ====================== ENVIO ======================
async function sendMessage(instance, phone, messageObj) {

    const instanceId = instance.instanceId || instance.id;
    const token = instance.token;

    // pega o texto da mensagem da dash
    const text =
        messageObj.text ||
        messageObj.texto ||
        messageObj.message ||
        messageObj.msg ||
        messageObj.body ||
        null;

    if (!text) {
        console.log("[ERRO] Mensagem vazia:", messageObj);
        return null;
    }

    const botao = messageObj.botao || null;

    const payload = {
        phone: phone,
        message: text,
        buttonActions: [
            {
                type: "URL",
                buttonText: botao?.texto || "Acessar",
                url: botao?.url || "https://google.com"
            }
        ],
        delayMessage: 1
    };

    const url = `https://api.w-api.app/v1/message/send-button-actions?instanceId=${instanceId}`;

    console.log("\n=================================");
    console.log("ENVIANDO PARA:", phone);
    console.log("Instance:", instanceId);
    console.log("Mensagem:", text);

    try {
        const res = await axios.post(url, payload, {
            headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        });

        console.log("[OK] STATUS:", res.status);
        console.log("Resposta:", res.data);
        return true;

    } catch (err) {
        console.log("[ERRO AO ENVIAR]");
        if (err.response) {
            console.log("Status:", err.response.status);
            console.log("Body:", err.response.data);
        } else {
            console.log("Error:", err.message);
        }
        return false;
    }
}

// ====================== LOOP ======================
async function start() {
    const instances = loadJson('instancias.json');
    const messages = loadJson('mensagem.json');
    let campaigns = loadJson('campanhas.json');

    if (!instances.length) return console.log("Nenhuma instância encontrada.");
    if (!messages.length) return console.log("Nenhuma mensagem encontrada.");
    if (!campaigns.length) return console.log("Nenhuma campanha ativa.");

    console.log("=== SISTEMA DE DISPARO INICIADO ===");

    for (let c = 0; c < campaigns.length; c++) {
        const campaign = campaigns[c];

        // ⚠️ Se já está concluída, pula
        if (campaign.status === "concluida") {
            console.log(`CAMPANHA ${campaign.nome} já concluída. Pulando...`);
            continue;
        }

        // pega a mensagem usando mensagemId ou messageId
        const messageId =
            campaign.messageId ||
            campaign.mensagemId ||
            null;

        const msg = messages.find(m => m.id === messageId) || messages[0];

        // pega os números (leads)
        const numeros =
            campaign.numeros ||
            campaign.leads ||
            campaign.contatos ||
            campaign.phones ||
            [];

        if (!numeros.length) {
            console.log("Nenhum número na campanha:", campaign.nome);
            continue;
        }

        const delayMin = campaign.delayMin || campaign.delayMinMs || 2000;
        const delayMax = campaign.delayMax || campaign.delayMaxMs || 4000;

        console.log("\n--- CAMPANHA:", campaign.nome, "---");

        for (let i = 0; i < numeros.length; i++) {
            const phone = numeros[i];
            const instance = instances[i % instances.length];

            await sendMessage(instance, phone, msg);

            const delay =
                Math.floor(Math.random() * (delayMax - delayMin)) + delayMin;
            console.log("Delay:", delay);
            await wait(delay);
        }

        console.log("CAMPANHA FINALIZADA:", campaign.nome);

        // ⚠️ MARCAR COMO CONCLUÍDA AUTOMATICAMENTE
        campaign.status = "concluida";

        // atualizar no arquivo
        campaigns[c] = campaign;
        saveJson("campanhas.json", campaigns);
    }

    console.log("\n=== TODAS AS CAMPANHAS PROCESSADAS ===");
    console.log("Sistema encerrado (auto-finalização ativada).");
}

start();
