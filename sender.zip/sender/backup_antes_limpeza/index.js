const express = require('express');
const fs = require('fs');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

function readJSON(file) {
    try { return JSON.parse(fs.readFileSync(file)); }
    catch { return []; }
}
function writeJSON(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ===============================
// INSTÂNCIAS
// ===============================
app.get('/api/instancias', (req, res) => {
    const data = readJSON('instancias.json');
    res.json(data);
});

app.post('/api/instancias/add', (req, res) => {
    let instancias = readJSON('instancias.json');

    instancias.push({
        nome: '',
        baseUrl: 'https://api.w-api.app/v1',
        instanceId: '',
        token: '',
        proxyHost: '',
        proxyPort: '',
        proxyUser: '',
        proxyPass: '',
        ativa: true
    });

    writeJSON('instancias.json', instancias);
    res.json({ ok: true, message: 'Instância adicionada.' });
});

app.post('/api/instancias/save', (req, res) => {
    const { instancias } = req.body;

    if (!Array.isArray(instancias)) {
        return res.status(400).json({ ok: false, message: 'Formato inválido.' });
    }

    writeJSON('instancias.json', instancias);
    res.json({ ok: true, message: 'Instâncias salvas.' });
});

app.post('/api/instancias/delete', (req, res) => {
    let instancias = readJSON('instancias.json');
    const { idx } = req.body;

    if (typeof idx !== 'number' || idx < 0 || idx >= instancias.length) {
        return res.status(400).json({ ok: false, message: 'Índice inválido.' });
    }

    instancias.splice(idx, 1);
    writeJSON('instancias.json', instancias);

    res.json({ ok: true, message: 'Instância removida.' });
});

// =============================================
// MENSAGENS
// =============================================
app.get('/api/mensagem', (req, res) => {
    const msgs = readJSON('mensagem.json');
    res.json(msgs[0] || {});
});

app.post('/api/salvar-mensagem', (req, res) => {
    writeJSON('mensagem.json', [req.body]);
    res.json({ ok: true, message: 'Mensagem salva.' });
});

// =============================================
// CAMPANHAS
// =============================================
app.get('/api/campanhas', (req, res) => {
    const data = readJSON('campanhas.json');
    res.json(data);
});

app.post('/api/campanhas', (req, res) => {
    const campanhas = readJSON('campanhas.json');

    const nova = {
        ...req.body,
        status: 'pendente',
        enviados: 0,
        erros: 0,
        total: req.body.leads.length,
        createdAt: Date.now()
    };

    campanhas.push(nova);
    writeJSON('campanhas.json', campanhas);

    res.json({ ok: true, message: 'Campanha criada!' });
});

// =============================================
// FRONTEND
// =============================================
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = 3000;
app.listen(PORT, () => console.log("Dashboard rodando na porta 3000"));
