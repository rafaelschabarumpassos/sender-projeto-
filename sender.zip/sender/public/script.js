// ================================================================
// FUNÇÃO BASE PARA CHAMADAS À API
// ================================================================
async function api(path, method = 'GET', body = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json' }
  };

  if (body) opts.body = JSON.stringify(body);

  const res = await fetch(path, opts);
  return res.json();
}

let mensagensCache = [];

// ================================================================
// 1. INSTÂNCIAS
// ================================================================
async function carregarInstancias() {
  const data = await api('/api/instancias');
  const tbody = document.getElementById('instances-body');
  if (!tbody) return;

  tbody.innerHTML = '';

  (data || []).forEach((inst, idx) => {
    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td><input value="${inst.nome || ''}" class="inst-nome" data-idx="${idx}" /></td>
      <td><input value="${inst.baseUrl || 'https://api.w-api.app/v1'}" class="inst-base" data-idx="${idx}" /></td>
      <td><input value="${inst.instanceId || ''}" class="inst-id" data-idx="${idx}" /></td>
      <td><input value="${inst.token || ''}" class="inst-token" data-idx="${idx}" /></td>
      <td><input value="${inst.proxyHost || ''}" class="inst-proxy-host" data-idx="${idx}" /></td>
      <td><input value="${inst.proxyPort || ''}" class="inst-proxy-port" data-idx="${idx}" /></td>
      <td><input value="${inst.proxyUser || ''}" class="inst-proxy-user" data-idx="${idx}" /></td>
      <td><input value="${inst.proxyPass || ''}" class="inst-proxy-pass" data-idx="${idx}" /></td>
      <td>
        <select class="inst-ativa" data-idx="${idx}">
          <option value="true" ${inst.ativa ? 'selected' : ''}>Sim</option>
          <option value="false" ${!inst.ativa ? 'selected' : ''}>Não</option>
        </select>
      </td>
      <td><button class="del-inst" data-idx="${idx}">Excluir</button></td>
    `;

    tbody.appendChild(tr);
  });

  document.querySelectorAll('.del-inst').forEach(btn => {
    btn.onclick = async () => {
      await api('/api/instancias/delete', 'POST', { idx: Number(btn.dataset.idx) });
      await carregarInstancias();
      await popularSelectInstancias();
    };
  });

  await popularSelectInstancias();
}

const btnSaveInstances = document.getElementById('save-instances-btn');
if (btnSaveInstances) {
  btnSaveInstances.onclick = async () => {
    const rows = document.querySelectorAll('#instances-body tr');
    const instancias = [];

    rows.forEach(r => {
      instancias.push({
        nome: r.querySelector('.inst-nome').value.trim(),
        baseUrl: r.querySelector('.inst-base').value.trim() || 'https://api.w-api.app/v1',
        instanceId: r.querySelector('.inst-id').value.trim(),
        token: r.querySelector('.inst-token').value.trim(),
        proxyHost: r.querySelector('.inst-proxy-host').value.trim(),
        proxyPort: r.querySelector('.inst-proxy-port').value.trim(),
        proxyUser: r.querySelector('.inst-proxy-user').value.trim(),
        proxyPass: r.querySelector('.inst-proxy-pass').value.trim(),
        ativa: r.querySelector('.inst-ativa').value === 'true'
      });
    });

    await api('/api/instancias/save', 'POST', instancias);
    alert('Instâncias salvas!');
    await carregarInstancias();
  };
}

const btnAddInst = document.getElementById('add-instance-btn');
if (btnAddInst) {
  btnAddInst.onclick = async () => {
    await api('/api/instancias/add', 'POST', {});
    await carregarInstancias();
  };
}

// ================================================================
// 2. MENSAGENS (MÚLTIPLAS)
// ================================================================
function preencherCamposMensagem(idx) {
  const msg = mensagensCache[idx];
  if (!msg) return;

  document.getElementById('msg-name').value = msg.nome || '';
  document.getElementById('msg-text').value = msg.texto || msg.text || '';
  document.getElementById('msg-footer').value = msg.rodape || '';
  document.getElementById('msg-button-text').value = msg.botao?.texto || '';
  document.getElementById('msg-button-url').value = msg.botao?.url || '';
}

async function salvarMensagensNoServidor() {
  await api('/api/mensagens/save', 'POST', { mensagens: mensagensCache });
  await popularSelectMensagens();
}

async function carregarMensagens() {
  let msgs = await api('/api/mensagens');
  if (!Array.isArray(msgs)) msgs = [];

  // Se não tiver nenhuma, cria uma padrão
  if (!msgs.length) {
    msgs.push({
      id: Date.now().toString(),
      nome: 'Mensagem 1',
      texto: '',
      rodape: '',
      botao: { texto: '', url: '' }
    });
    await api('/api/mensagens/save', 'POST', { mensagens: msgs });
  }

  mensagensCache = msgs;

  const select = document.getElementById('msg-select');
  if (!select) return;

  select.innerHTML = '';
  mensagensCache.forEach((m, idx) => {
    const opt = document.createElement('option');
    opt.value = idx;
    opt.textContent = m.nome || `Mensagem ${idx + 1}`;
    select.appendChild(opt);
  });

  select.value = '0';
  preencherCamposMensagem(0);
  await popularSelectMensagens();
}

const msgSelect = document.getElementById('msg-select');
if (msgSelect) {
  msgSelect.onchange = () => {
    const idx = Number(msgSelect.value) || 0;
    preencherCamposMensagem(idx);
  };
}

const btnNewMsg = document.getElementById('new-message-btn');
if (btnNewMsg) {
  btnNewMsg.onclick = async () => {
    mensagensCache.push({
      id: Date.now().toString(),
      nome: 'Nova mensagem',
      texto: '',
      rodape: '',
      botao: { texto: '', url: '' }
    });
    await salvarMensagensNoServidor();
    await carregarMensagens();
  };
}

const btnDeleteMsg = document.getElementById('delete-message-btn');
if (btnDeleteMsg) {
  btnDeleteMsg.onclick = async () => {
    if (mensagensCache.length <= 1) {
      alert('Precisa ter pelo menos 1 mensagem.');
      return;
    }
    const idx = Number(document.getElementById('msg-select').value) || 0;
    mensagensCache.splice(idx, 1);
    await salvarMensagensNoServidor();
    await carregarMensagens();
  };
}

const btnSaveMsg = document.getElementById('save-message-btn');
if (btnSaveMsg) {
  btnSaveMsg.onclick = async () => {
    const idx = Number(document.getElementById('msg-select').value) || 0;
    const msg = mensagensCache[idx];
    if (!msg) return;

    msg.nome = document.getElementById('msg-name').value.trim();
    msg.texto = document.getElementById('msg-text').value.trim();
    msg.rodape = document.getElementById('msg-footer').value.trim();
    msg.botao = {
      texto: document.getElementById('msg-button-text').value.trim(),
      url: document.getElementById('msg-button-url').value.trim()
    };

    await salvarMensagensNoServidor();
    alert('Mensagem salva!');
    await carregarMensagens();
  };
}

// ================================================================
// 3. POPULAR SELECTS NA CRIAÇÃO DE CAMPANHA
// ================================================================
async function popularSelectInstancias() {
  const data = await api('/api/instancias');
  const select = document.getElementById('camp-instances');
  if (!select) return;

  select.innerHTML = '';

  (data || []).forEach((inst, idx) => {
    const opt = document.createElement('option');
    opt.value = idx;
    opt.textContent = inst.nome || `Instância ${idx + 1}`;
    select.appendChild(opt);
  });
}

async function popularSelectMensagens() {
  const msgs = await api('/api/mensagens');
  const select = document.getElementById('camp-message');
  if (!select) return;

  select.innerHTML = '';

  (msgs || []).forEach((m, idx) => {
    const opt = document.createElement('option');
    opt.value = idx;
    opt.textContent = m.nome || `Mensagem ${idx + 1}`;
    select.appendChild(opt);
  });
}

// ================================================================
// 4. CRIAR CAMPANHA
// ================================================================
const btnCreateCamp = document.getElementById('create-campaign-btn');

if (btnCreateCamp) {
  btnCreateCamp.onclick = async () => {
    const nome = document.getElementById('camp-name').value.trim();

    const leads = document
      .getElementById('camp-leads')
      .value.trim()
      .split(/\n+/)
      .map(x => x.trim())
      .filter(Boolean);

    const instancias = Array.from(
      document.getElementById('camp-instances').selectedOptions
    ).map(x => Number(x.value));

    const messageIndex = Number(document.getElementById('camp-message').value);

    const delayMinMs = Number(document.getElementById('camp-delay-min').value) || 2000;
    const delayMaxMs = Number(document.getElementById('camp-delay-max').value) || 4000;

    const pauseEnabled = document.getElementById('camp-pause-enabled').checked;
    const pauseAfter = Number(document.getElementById('camp-pause-after').value) || 0;
    const pauseTime = Number(document.getElementById('camp-pause-time').value) || 0;

    const body = {
      nome,
      leads,
      instancias,
      messageIndex: isNaN(messageIndex) ? 0 : messageIndex,
      delayMinMs,
      delayMaxMs,
      pauseEnabled,
      pauseAfter,
      pauseTime
    };

    await api('/api/campanhas', 'POST', body);
    alert('Campanha criada!');
    document.getElementById('camp-name').value = '';
    document.getElementById('camp-leads').value = '';
    await carregarCampanhas();
  };
}

// ================================================================
// 5. LISTAR CAMPANHAS
// ================================================================
async function carregarCampanhas() {
  const data = await api('/api/campanhas');
  const tbody = document.getElementById('campaigns-body');
  if (!tbody) return;

  tbody.innerHTML = '';

  (data || []).forEach(c => {
    const tr = document.createElement('tr');

    tr.innerHTML = `
      <td>${c.nome}</td>
      <td>${c.status}</td>
      <td>${c.enviados}/${c.total}</td>
      <td>${c.erros}</td>
      <td>${Array.isArray(c.instancias) ? c.instancias.length : 0}</td>
      <td>${new Date(c.createdAt).toLocaleString()}</td>
    `;

    tbody.appendChild(tr);
  });
}

// ================================================================
// 6. INIT
// ================================================================
carregarInstancias();
carregarMensagens();
carregarCampanhas();
setInterval(carregarCampanhas, 3000);
